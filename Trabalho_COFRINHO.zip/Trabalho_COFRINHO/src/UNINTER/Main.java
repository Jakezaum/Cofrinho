package UNINTER;

import java.util.HashMap;
import java.util.Scanner;

public class Main {
	
	public static void main(String[] args) {
	    int tipo;

		Scanner teclado = new Scanner(System.in);
		
		Cofrinho cofrinho = new Cofrinho();
		
		while(true) {
			System.out.println();
			System.out.println("------------------- Cofrinho ------------------");
			System.out.println("| 1 - Adicionar Moeda                         |");
			System.out.println("| 2 - Remover Moeda                           |");
			System.out.println("| 3 - Listar Moedas                           |");
			System.out.println("| 4 - Calcular total convertido para Real     |");
			System.out.println("| 5 - Encerrar                                |");
			System.out.println("-----------------------------------------------");

			//VERIFICAÇÃO DAS OPÇÕES
			int opcao;
			do {
                while (!teclado.hasNextInt()) { //VERIFICA SE É INTEIRO
                    System.out.println("Opção Inválida. Tente novamente!");
                    teclado.next(); //RESTART DA ENTRADA
                }
                opcao = teclado.nextInt();
                if (opcao <= 0 || opcao > 5) { //VERIFICA SE A OPÇÃO É VÁLIDO
                    System.out.println("Opção Inválida. Tente novamente!");
                }   
            } while (opcao <= 0 || opcao > 5); //REPETE ENQUANTO A OPÇÃO FOR INVÁLIDA
			
//SWITCH DAS OPÇÕES
			switch(opcao) {
		//ADICIONAR MOEDAS
			case 1:
			    int tipoAdicionar;
			    do {
			    	System.out.println();
			        System.out.println("Qual o tipo da moeda que deseja ADICIONAR?");
			        System.out.println("1 - REAL");
			        System.out.println("2 - DOLAR");
			        System.out.println("3 - EURO");
			        
			        while (!teclado.hasNextInt()) { //VERIFICA SE É INTEIRO
				    	System.out.println();
			            System.out.println("Opção Inválida! Tente novamente.");
				    	System.out.println();
			            System.out.println("Qual o tipo da moeda que deseja ADICIONAR?");
			            System.out.println("1 - REAL");
			            System.out.println("2 - DOLAR");
			            System.out.println("3 - EURO");
			        }
			        tipoAdicionar = teclado.nextInt();

			    } while (tipoAdicionar <= 0 || tipoAdicionar > 3); //REPETE ENQUANTO A OPÇÃO FOR INVÁLIDA
			    
			    
//			    TESTANDO METODOLOGIA NOVA. FUNCIONAL!
//			    
//			    System.out.println();
//		        System.out.println("Qual o valor da moeda que deseja ADICIONAR? ");
//		        double valor = teclado.nextDouble();
//
//			    HashMap<String, Moeda> mapa = new HashMap<String, Moeda>();
//			    
//			    mapa.put("1", new Real(valor));
//			    mapa.put("2", new Dolar(valor));
//			    mapa.put("3", new Euro(valor));
//			    cofrinho.adicionar(mapa.get(Integer.toString(tipoAdicionar)));
			    
			    
			    
			    
			    //ADICIONAR REAL
			    if (tipoAdicionar == 1) {
			    	System.out.println();
			        System.out.println("Qual o valor da moeda que deseja ADICIONAR? ");
			        double valor = teclado.nextDouble();
			        Real real = new Real(valor);
			       	cofrinho.adicionar(real);                             
			       	break;
			        
			    //ADICIONAR DÓLAR
			    } else if (tipoAdicionar == 2) {
			    	System.out.println();
			        System.out.println("Qual o valor da moeda que deseja ADICIONAR? ");
			        double valor = teclado.nextDouble();
			        Dolar dolar = new Dolar(valor);
			        cofrinho.adicionar(dolar);
			        break;
			        
			    //ADICIONAR EURO
			    } else if (tipoAdicionar == 3) {
			    	System.out.println();
			        System.out.println("Qual o valor da moeda que deseja ADICIONAR? ");
			        double valor = teclado.nextDouble();
			        Euro euro = new Euro(valor);
			        cofrinho.adicionar(euro);
			        break;
			        
			    //EXCEPTION RESPONDIDA
			    } else {
			        System.out.println("Opção inválida! Tente novamente.");
			        break;
			    }
					
		//REMOVER MOEDAS
				case 2:
					int tipoRemover;
				    do {
				    	System.out.println();
				        System.out.println("Qual o tipo da moeda que deseja REMOVER?");
				        System.out.println("1 - REAL");
				        System.out.println("2 - DOLAR");
				        System.out.println("3 - EURO");
				        
				        while (!teclado.hasNextInt()) { //VERIFICA SE É INTEIRO
					    	System.out.println();
				            System.out.println("Opção Inválida! Tente novamente.");
					    	System.out.println();
				            System.out.println("Qual o tipo da moeda que deseja REMOVER?");
				            System.out.println("1 - REAL");
				            System.out.println("2 - DOLAR");
				            System.out.println("3 - EURO");
				        }
				        tipoRemover = teclado.nextInt();

				    } while (tipoRemover <= 0 || tipoRemover > 3); //REPETE ENQUANTO A OPÇÃO FOR INVÁLIDA
				    
				    //REMOVER REAL
				    if (tipoRemover == 1) {
				    	System.out.println();
				        System.out.println("Qual o valor da moeda que deseja REMOVER? ");
				        double valor = teclado.nextDouble();
				        Moeda moeda = new Real(valor);
				        cofrinho.remover(moeda);                           
				        break;
				        
				    //REMOVER DÓLAR
				    } else if (tipoRemover == 2) {
				    	System.out.println();
				        System.out.println("Qual o valor da moeda que deseja REMOVER? ");
				        double valor = teclado.nextDouble();
				        Moeda moeda = new Dolar(valor);
				        cofrinho.remover(moeda);                           
				        break;
				        
				    //REMOVER EURO
				    } else if (tipoRemover == 3) {
				    	System.out.println();
				        System.out.println("Qual o valor da moeda que deseja REMOVER? ");
				        double valor = teclado.nextDouble();
				        Moeda moeda = new Euro(valor);
				        cofrinho.remover(moeda);                           
				        break;
				        
				    //EXCEPTION RESPONDIDA
				    } else {
				    	System.out.println();
				        System.out.println("Opção inválida! Tente novamente.");
				        break;
				    }
						
		//LISTAR MOEDAS
				case 3:
					System.out.println();
					System.out.println("Suas moedas:");
					cofrinho.listar();
					break;
		
		//VALOR TOTAL CONVERTIDO
				case 4:
					cofrinho.valorTotal();
					break;
					
		//FINALIZA O PROGRAMA
				case 5:
					System.out.println();
					System.out.println("Encerrando o programa...");
			        teclado.close();
			        return;
				default:
					System.out.println();
					System.out.println("Opção inválida! Tente novamente.");
			}		
					
		}
	}
}