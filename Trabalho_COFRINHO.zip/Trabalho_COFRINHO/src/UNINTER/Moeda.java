package UNINTER;

import java.util.Objects;

//ATRIBUTOS
public abstract class Moeda {
	double valor;

//CONSTRUTORES
	public Moeda(double valor) {
		this.valor = valor;
	}
	
//MÉTODOS
	public double getValor() {
		return valor;
	}
	
	public abstract void info();

	public abstract String toString();

	public abstract double converter();

//EQUALS
	@Override
	public boolean equals(Object obj) {
		if (obj == null)
			return false;
		if(getClass() != obj.getClass())
			return false;
		Moeda other = (Moeda) obj;
		if (valor != other.valor)
			return false;
		
		return true;
		
	}

}