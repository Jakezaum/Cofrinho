package UNINTER;

import java.util.Objects;

public class Euro extends Moeda{
	
//CONSTRUTOR
	public Euro(double valor) {
		super(valor);
	}

//MÉTODOS
	@Override
	public double converter() {
		return valor * 5.39;
	}
	
	public void info() { //DATA DE CONVERSÃO: 10/07/2023
		System.out.println("Valor convertido de EURO para REAL : " + this.converter());
	}
	
//TOSTRING
	@Override
	public String toString() {
		return "     EURO: " + valor;
	}

}