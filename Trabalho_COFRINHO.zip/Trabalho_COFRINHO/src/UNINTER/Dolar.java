package UNINTER;

import java.util.Objects;

public class Dolar extends Moeda{
	
//CONSTRUTOR
	public Dolar(double valor) {
		super(valor);
	}

//MÉTODOS
	@Override
	public double converter() {
		return valor * 4.90;
	}
	
	public void info() { //DATA DE CONVERSÃO: 10/07/2023
		System.out.println("Valor convertido de DÓLAR para REAL : " + this.converter());
	}
	
//TOSTRING
	@Override
	public String toString() {
		return "     DÓLAR: " + valor;
	}
	
	
}
