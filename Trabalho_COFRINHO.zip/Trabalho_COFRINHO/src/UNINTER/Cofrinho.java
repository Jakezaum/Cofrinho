package UNINTER;

import java.util.ArrayList;

public class Cofrinho {
	
//LISTA
	private ArrayList<Moeda> coinsList = new ArrayList<Moeda>(); 
	
//ADICIONAR MOEDAS
		public void adicionar(Moeda m) {
			coinsList.add(m);
		}
		
//REMOVER MOEDAS 

		public void remover(Moeda moeda) {
		    for (Moeda m : coinsList) {
		    	if(m.equals(moeda)) {
		        	
		        	coinsList.remove(m);
		            return;
		        }
		    }
		    System.out.println();
	        System.out.println("Não foi encontrada uma moeda para remover.");
		}
		
//LISTAGEM DE MOEDAS
		public void listar() {
			for(Moeda m : coinsList) {
				System.out.println(m);
			}
		}
		
//CONVERSÃO
		public double valorTotal() {
				double total = 0;
		     for(Moeda m : coinsList) {
		         total += m.converter();
		     }
		     System.out.println("Total: " + total);
		     return total;
		}
}
