package UNINTER;

import java.util.Objects;

public class Real extends Moeda{

//CONSTRUTOR
	public Real(double valor) {
		super(valor);
	}

//MÉTODOS
	@Override
	public double converter() {
		return valor;
	}
	
	public void info() { //DATA DE CONVERSÃO: 10/07/2023
		System.out.println("Não há conversão para essa moeda.");
	}
	
//TOSTRING
	@Override
	public String toString() {
		return "     REAL: " + valor;
	}
	
	
}